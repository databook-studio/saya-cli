import { writeFileSync } from 'node:fs';

const sentinel = process.env.SAYA_TEST_PREPARE_SENTINEL;
if (sentinel) writeFileSync(sentinel, 'prepare lifecycle ran');
