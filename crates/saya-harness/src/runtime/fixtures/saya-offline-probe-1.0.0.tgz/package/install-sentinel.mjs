import { writeFileSync } from 'node:fs';

const sentinel = process.env.SAYA_TEST_INSTALL_SENTINEL;
if (sentinel) writeFileSync(sentinel, 'install lifecycle ran');
