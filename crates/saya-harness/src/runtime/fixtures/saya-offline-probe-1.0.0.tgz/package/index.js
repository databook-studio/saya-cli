export const probeValue = 'saya-offline-cache-probe';
